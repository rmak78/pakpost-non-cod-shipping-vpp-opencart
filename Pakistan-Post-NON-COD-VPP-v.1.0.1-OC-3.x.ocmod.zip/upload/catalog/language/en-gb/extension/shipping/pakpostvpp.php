<?php
// Text
$_['text_title']  = 'Pakistan Post Registered Post (Cash Only)';
$_['text_weight'] = 'Weight (grams):';